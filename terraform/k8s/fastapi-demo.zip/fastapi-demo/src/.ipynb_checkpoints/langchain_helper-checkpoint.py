from dotenv import load_dotenv
import os
import pickle
import faiss

from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.vectorstores import Chroma
from langchain.docstore.document import Document
from langchain_community.vectorstores import FAISS
#Import Python modules
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.prompts import PromptTemplate
from langchain_text_splitters import CharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
# Load environment variables from .env file
load_dotenv()

# Access environment variables
api_key = os.getenv('GOOGLE_API_KEY')




#Load the models
llm = ChatGoogleGenerativeAI(model="gemini-pro")
embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")

#Load the PDF and create chunks
#loader = PyPDFLoader("codebasics_faqs.csv")
from langchain.document_loaders.csv_loader import CSVLoader

#Create the retrieval chain
template = """
You are a helpful AI assistant.
Answer based on the context provided. 
context: {context}
input: {input}
answer:
"""
path_to_vectordb = "./faiss_index"
# Paths to save the data
index_path = "faiss_index.bin"
documents_path = "documents.pkl"


#Turn the chunks into embeddings and store them in Chroma
def create_vector_db():
    loader = CSVLoader(file_path='codebasics_faqs.csv', source_column='prompt', encoding='iso-8859-1')
    documents = loader.load()
    text_splitter = CharacterTextSplitter(
        separator=".",
        chunk_size=250,
        chunk_overlap=50,
        length_function=len,
        is_separator_regex=False,
    )
    docs = text_splitter.split_documents(documents)
    #pages = loader.load_and_split(text_splitter)
    #vectordb=Chroma.from_documents(pages,embeddings)
    vectordb = FAISS.from_documents(docs, embeddings)
    vectordb.save_local(path_to_vectordb)
    # Save FAISS index
    #faiss.write_index(vectordb.index, index_path)
    # Save documents
    # with open(documents_path, 'wb') as f:
    #     pickle.dump(documents, f)
    
def get_qa_chain():
    # Load the vector database from local folder
    vectordb = FAISS.load_local(path_to_vectordb,embeddings,allow_dangerous_deserialization=True)
    #index = faiss.read_index(index_path)
    # Create retriever for querying the vector database
    # Load documents with the allow_dangerous_deserialization flag set to True
    # with open(documents_path, 'rb') as f:
    #     loaded_documents = pickle.load(f, allow_dangerous_deserialization=True)

    # Reconstruct the FAISS vector store
    #vectordb = FAISS(embeddings=embeddings, index=index, docstore=loaded_documents)

    retriever = vectordb.as_retriever(score_threshold=0.7)
    prompt_template = """Given the following context and a question, generate an answer based on this context only.
    In the answer try to provide as much text as possible from "response" section in the source document context without making much changes.
    If the answer is not found in the context, kindly state "I don't know." Don't try to make up an answer.

    CONTEXT: {context}

    QUESTION: {question}"""
    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )
    chain = RetrievalQA.from_chain_type(llm=llm,
                                        chain_type="stuff",
                                        retriever=retriever,
                                        input_key="query",
                                        return_source_documents=True,
                                        chain_type_kwargs={"prompt": PROMPT})
    return chain
    
#Configure Chroma as a retriever with top_k=5
#retriever = vectordb.as_retriever(search_kwargs={"k": 5})

# prompt = PromptTemplate.from_template(template)
# combine_docs_chain = create_stuff_documents_chain(llm, prompt)
# retrieval_chain = create_retrieval_chain(retriever, combine_docs_chain)

# #Invoke the retrieval chain
# response=retrieval_chain.invoke({"input":"Do you have javascript course"})

# #Print the answer to the question
# print(response["answer"])

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8080)