import streamlit as st
from langchain_helper import get_qa_chain, create_vector_db, log_qa_interaction

st.title("Q&A Application 🤖")

# Sidebar for creating vector DB
with st.sidebar:
    st.header("Setup")
    if st.button("Create Knowledge Base"):
        with st.spinner("Creating vector database..."):
            create_vector_db()
            st.success("Knowledge base created successfully!")

# Initialize session state for storing Q&A history
if 'qa_history' not in st.session_state:
    st.session_state.qa_history = []

# Main Q&A section
question = st.text_input("Ask a question:")

if question:
    chain = get_qa_chain()
    
    with st.spinner("Thinking..."):
        response = chain.invoke(question)
    
    st.header("Answer")
    st.write(response)
    
    # Store current Q&A in session state
    current_qa = {
        'question': question,
        'answer': response,
        'feedback': None,
        'feedback_comment': None
    }
    
    # Feedback section
    st.markdown("---")
    st.subheader("Was this answer helpful?")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("👍 Helpful", key=f"thumbs_up_{question}"):
            log_qa_interaction(question, response, feedback="positive")
            st.success("Thank you for your feedback!")
            current_qa['feedback'] = 'positive'
    
    with col2:
        if st.button("👎 Not Helpful", key=f"thumbs_down_{question}"):
            log_qa_interaction(question, response, feedback="negative")
            st.warning("Thank you for your feedback. We'll work on improving!")
            current_qa['feedback'] = 'negative'
    
    # Optional: Add comment box for detailed feedback
    feedback_comment = st.text_area("Additional comments (optional):", key=f"comment_{question}")
    
    if feedback_comment:
        if st.button("Submit Comment", key=f"submit_comment_{question}"):
            log_qa_interaction(
                question, 
                response, 
                feedback=current_qa.get('feedback'),
                feedback_comment=feedback_comment
            )
            st.success("Comment submitted!")
            current_qa['feedback_comment'] = feedback_comment
    
    # Add to history
    st.session_state.qa_history.append(current_qa)

# Display history in sidebar
with st.sidebar:
    st.markdown("---")
    st.header("Recent Questions")
    
    if st.session_state.qa_history:
        for idx, qa in enumerate(reversed(st.session_state.qa_history[-5:])):
            with st.expander(f"Q: {qa['question'][:50]}..."):
                st.write(f"**Answer:** {qa['answer'][:100]}...")
                if qa['feedback']:
                    st.write(f"**Feedback:** {'👍' if qa['feedback'] == 'positive' else '👎'}")