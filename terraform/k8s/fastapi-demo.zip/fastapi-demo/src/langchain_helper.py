from dotenv import load_dotenv
import os
import pickle
import faiss
import json
from datetime import datetime,timezone

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
#Import Python modules
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_text_splitters import CharacterTextSplitter
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from pathlib import Path
from langchain_groq import ChatGroq
# Load environment variables from .env file
load_dotenv()

# Access environment variables
api_key = os.getenv('GROQ_API_KEY')
BASE_DIR = Path(__file__).resolve().parent   # => /app/src
csv_path = BASE_DIR / "codebasics_faqs.csv"



#Load the models
#llm = ChatGoogleGenerativeAI(model="gemini-pro")
#embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    temperature=0.0,
    max_retries=2,
    # other params...
)

#Load the PDF and create chunks
#loader = PyPDFLoader("codebasics_faqs.csv")
from langchain_community.document_loaders.csv_loader import CSVLoader

#Create the retrieval chain
template = """
You are a helpful AI assistant.
Answer based on the context provided.
context: {context}
input: {input}
answer:
"""
path_to_vectordb = "./faiss_index"
# Paths to save the data
#index_path = "faiss_index/index.faiss"
#documents_path = "faiss_index/index.pkl"

#BASE_DIR = os.path.dirname(os.path.abspath(__file__))
#FAISS_INDEX_PATH = os.path.join(BASE_DIR, "faiss_index")

FAISS_DIR = Path(os.getenv("FAISS_DIR", "/faiss_index"))
FAISS_DIR.mkdir(parents=True, exist_ok=True)


#Turn the chunks into embeddings and store them in Chroma
def create_vector_db():
    loader = CSVLoader(file_path='codebasics_faqs.csv', source_column='prompt', encoding='iso-8859-1')
    documents = loader.load()
    text_splitter = CharacterTextSplitter(
        separator=".",
        chunk_size=250,
        chunk_overlap=50,
        length_function=len,
        is_separator_regex=False,
    )
    docs = text_splitter.split_documents(documents)
    #pages = loader.load_and_split(text_splitter)
    #vectordb=Chroma.from_documents(pages,embeddings)
    vectordb = FAISS.from_documents(docs, embeddings)
    vectordb.save_local(FAISS_DIR)
    # Save FAISS index
    #faiss.write_index(vectordb.index, index_path)
    # Save documents
    # with open(documents_path, 'wb') as f:
    #     pickle.dump(documents, f)

def get_qa_chain():
    # Load the vector database from local folder
    vectordb = FAISS.load_local(FAISS_DIR,embeddings,allow_dangerous_deserialization=True)
    #index = faiss.read_index(index_path)
    # Create retriever for querying the vector database
    # Load documents with the allow_dangerous_deserialization flag set to True
    #with open(documents_path, 'rb') as f:
       #loaded_documents = pickle.load(f)

    # Reconstruct the FAISS vector store
    #vectordb = FAISS(embedding_function=embeddings, index=index, docstore=loaded_documents,index_to_docstore_id=index_to_docstore_id)

    retriever = vectordb.as_retriever(search_kwargs={"k":5})
    prompt_template = """Given the following context and a question, generate an answer based on this context only.
    In the answer try to provide as much text as possible from "response" section in the source document context without making much changes.
    If the answer is not found in the context, kindly state "I don't know." Don't try to make up an answer.

    CONTEXT: {context}

    QUESTION: {question}"""
    prompt = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )
    def format_docs(docs):
       return "\n\n".join(doc.page_content for doc in docs)
    chain = ({
               "context":retriever | format_docs,
                "question": RunnablePassthrough()
              }
              | prompt
               | llm
               | StrOutputParser()
            )
    return chain

# Add this function at the end of langchain_helper.py
def log_qa_interaction(question, answer, feedback=None, feedback_comment=None):
    """Log Q&A interactions with feedback to a structured format for Filebeat"""
    log_entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": "qa_interaction",
        "question": question,
        "answer": answer,
        "feedback": feedback,  # "positive", "negative", or None
        "feedback_comment": feedback_comment,
        "application": "streamlit-qa-app",
        "environment": "production"
    }
    
    # Log as JSON for easy parsing by Filebeat/Logstash
    print(json.dumps(log_entry))
    
    return log_entry
#Configure Chroma as a retriever with top_k=5
#retriever = vectordb.as_retriever(search_kwargs={"k": 5})

# prompt = PromptTemplate.from_template(template)
# combine_docs_chain = create_stuff_documents_chain(llm, prompt)
# retrieval_chain = create_retrieval_chain(retriever, combine_docs_chain)

# #Invoke the retrieval chain
# response=retrieval_chain.invoke({"input":"Do you have javascript course"})

# #Print the answer to the question
# print(response["answer"])

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8080)